<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="aboutus.css">
	<title>about us</title>
</head>
<body>
<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a href="index.php">Home</a></li>
				<li><a href="services.php"  >Service</li></a>
				<li><a href="outlet.php">Find Outlet</a></li>
				<li><a href="trending.php">Business Trending</a></li>
				<li><a  class="active" href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
</body>
</html>