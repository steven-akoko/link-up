<?php
include ('connect.php');
if(isset($_POST['signup_btn']))
{
	$firstname=mysqli_real_escape_string($conn,$_POST['firstname']);
	$lastname=mysqli_real_escape_string($conn, $_POST['lastname']);
	$email=mysqli_real_escape_string($conn, $_POST['email']);
	$password1=mysqli_real_escape_string($conn, $_POST['password1']);
	$password2=mysqli_real_escape_string($conn, $_POST['password2']);

	//test the condition of the input field;
	if(empty('$firstname'))
	{
		$Error="field must be filled";
	}
}

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="Register.css">
	<link rel="stylesheet" href="../lib/w3.css">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Register</title>
	<style>
		.error
		{
			color:darkred;
		}
	</style>
</head>
<body>
	<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a href="index.php">Home</a></li>
				<li><a href="services.php" >Service</li></a>
				<li><a href="outlet.php">Find Outlet</a></li>
				<li><a href="trending.php">Business Trending</a></li>
				<li><a class="active" href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
	<h1 id="heading">Creat account</h1>
	<div class="sign-btn">
		<div class="main-btn">
		<div class="sign-category">
		<i class="fa fa-users"></i>
			<h1>service provider</h1>
			<p>Are you qualified and tired of searching for job? dont worry, we are here to link
			you with ready clients everyday, all you need is too register</p>
			<a href="client-reg.php">sign-up as a client</a>
	</div>
	<div class="sign-category">
		<i class="fa fa-user"></i>
		<h1>client</h1>
		<p>Are you tired of looking for trusted service provider?
		not anymore with servall we link you with thousands of qualified personel at the 
	comfort of your place anytime anywhere</p>
	<a href="sprovider-reg.php">sign-up as a service provider</a>
	</div>
</div>
</div>

</body>
</html>