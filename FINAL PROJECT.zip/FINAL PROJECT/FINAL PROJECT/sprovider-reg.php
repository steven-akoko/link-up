<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="sprovider-reg.css">
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>service provider  registration form</title>
</head>
<body>
	<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a href="index.php">Home</a></li>
				<li><a href="services.php" class="active" >Service</li></a>
				<li><a href="outlet.php">Find Outlet</a></li>
				<li><a href="trending.php">Business Trending</a></li>
				<li><a href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
		<h1 id="info" style="font-size:30px;">create service provider account</p>
			<h2 id="info">many clients are waiting to connect with you</h2>
			<h1 id="info">step 1/2</h1>

	<div id="view">
		<div class="guide">
		<h1 id="intro"style="margin-left:10px;font-size:20px;color:red;">personal information</h1>
		<p >This is information pertaining 
		to you as an individual</p>
	</div>
		<div class="form-box">
			<form>
				<div class="group-input">
					<label>FirstName</label>
				<input  class="input-filed" type="text" placeholder="enter firstname">
				<label>LastName</label>
				<input type="tetx" class="input-filed" type="text" name=""placeholder="enter lastname">
				<label>Email</label>
				<input type="email" class="input-filed" type="text" name=""placeholder="enter your email">
				<label>password</label>
				<input type="password" class="input-filed" type="text" name=""placeholder="enter password">
				<label>Confirm Password</label>
				<input type="password" class="input-filed" type="text" name=""placeholder="confirm password">
				<label>Date of birth</label>
				<input type="date" class="input-filed"name=""placeholder="enter date of birth">
				<label>select your gender</label>
				<select class="input-filed">
					<option>male</option>
					<option>Female</option>
				</select>
				<label>nationality</label>
				<select class="input-filed">
					<option>uganda</option>
					<option>kenya</option>
					<option>tanzania</option>
				</select>
				<label class="input-filed">select your location</label>
				<select class="input-filed">
					<option>kisumu</option>
				</select>
				<label class="input-filed">your country code</label>
				<select class="input-filed">
					<option>+254</option>
				</select>
				<label>phone number</label>
				<input class="input-filed" type="text" name=""placeholder="enter phone number">
				
			</div>
			<a href="#view">
			<button type="button">Next</button>
			</a>
			</form>

		</div>
	</div>
	 <hr>
 <h1 id="info">step 2 of 2</h1>
	<div id="view">
		<div class="guide">
		<h1 id="intro"style="margin-left:10px;font-size:20px;color:red;">work information</h1>
		<p >This is information pertaining to your past work experience and your qualifications</p>
	</div>
		<div class="form-box">
			<form action="" method="" enctype="multipart/form-data">
				<div class="group-input">
					<label>Highest Qualification</label>
				<select class="input-filed">
					<option>PHD</option>
					<option>Masters</option>
					<option>Undergraduate</option>
					<option>Post-Diploma</option>
					<option>Diploma</option>
				</select>
				<label>Current Job Title</label>
				<select class="input-filed">
					<option></option>
					
				</select>
				<label>Year of experience</label>
				<input type="number" class="input-filed" type="text" name="">
				<label>Availability</label>
				<select class="input-filed">
					<option>male</option>
					<option>Female</option>
				</select>
				<br>
				<label>upload your certicates</label>
				 <input type="file" id="myfile" name="myfile" multiple />
			</div>
			<p>Optionally upload a CV any other relevant certicates no larger than 10MB for file types .pdf .doc .docx .rtf
Please note:these certicates, however you can skip the CV upload on sign u</p>
			<button type="button">Next</button>

			</form>

		</div>

		

	</div>

</body>
</html>