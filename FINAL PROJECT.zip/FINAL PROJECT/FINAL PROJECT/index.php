
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="../lib/w3.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	<title>home page</title>
</head>
<body>
	<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a class="active" id="nav-links" href="index.php">Home</a></li>
				<li><a href="services.php" id="nav-links">Service</li></a>
				<li><a href="outlet.php" id="nav-links">Find Outlet</a></li>
				<li><a href="trending.php" id="nav-links">Business Trending</a></li>
				<li><a href="login.php" id="nav-links">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
		<div class="service">
  	<div class="title">
  		<h2>What we do</h2>
		<hr style="width:100%;margin-bottom:10px;">
  	</div>
  	<div class="box">
  		<div class="card">
  			<i class="fa fa-bars"></i>
  			<h5>Finding the best outlets</h5>
  			<div class="par">
  				<p>We help you build a nice and tidy websites that provide a very convenient user interaction
  				 our goal is to deliver on the quality as our price is extremely affordable</p>
  				 <p style="text-align: center;">
  				 	<a class="button" href="">Read more</a>
  				 </p>
  		</div>

  	</div>
  	<div class="card">
  			<i class="fa fa-user"></i>
  			<h5>Easy service provision</h5>
  			<div class="par">
  				<p>We help you build a nice and tidy websites that provide a very convenient user interaction
  				 our goal is to deliver on the quality as our price is extremely affordable</p>
  				 <p style="text-align: center;">
  				 	<a class="button" href="">Read more</a>
  				 </p>
  		</div>

  	</div>
  	<div class="card">
  			<i class="fa fa-bell"></i>
  			<h5>Business Trending info</h5>
  			<div class="par">
  				<p>We help you build a nice and tidy websites that provide a very convenient user interaction
  				 our goal is to deliver on the quality as our price is extremely affordable</p>
  				 <p style="text-align: center;">
  				 	<a class="button" href="">Read more</a>
  				 </p>
  		</div>
  	</div>
  </div>
</div>
<hr style="width: 100%;margin-bottom: 5px;" >
<p id="user-instruction">what are you waiting for? sign with servall to enjoy the listed opportunity ,its just one click away</p>

		<div class="main-box">
			<div class=mainbox-info>
				<div class="aboutcover">
			<h1>Benefits of signing up with
			servall cooperation are:</h1>
			<ul>
				<li> getting fast and reliable service</li>
				<li>customer dissonance avoidance</li>
				<li>faster outlet reach</li>
				<li>getting fast hand information</li>
				<li>Marketing your business for wider market</li>
				<li>providing business opportuinity for professionals</li>

			</ul>
			</div>
					<div class="aboutcover">
			<h1>type of service a client can request:</h1>
			<ul>
				<li> plumbing</li>
				<li>Electricity connection</li>
				<li>Gardenning</li>
				<li>General house services</li>
				<li>Tutors</li>
				<li>Technicians</li>
				<!--
				<li>Delivery guy</li>
				<li>Transport</li>
				<li>Health care providers e.g nurses,doctors,nutritionist</li>
				<li>operators</li>
			-->

			</ul>
			</div>
					<div class="aboutcover">
			<h1>type of the outlet/ammenties we link you with:</h1>
			<ul>
				<li>Restaurants</li>
				<li>Clubs</li>
				<li>Hotels</li>
				<li>hardwares</li>
				<li>Malls</li>
				<li>hospitals</li>
				<li>schools</li>
				<li>Fashion and designs</li>

			</ul>
			</div>
					</div>
		</div>
  
  <!--footer begins here-->
 <footer class="footer">
 	<div class="container-f">
 		<div class="footer-box">
 			<div class="footer-col">
 				<h5>companies</h5>
 				<ul>
 					<li><a href="#">about us</a></li>
 					<li><a href="#">affiliate programm</a></li>
 					<li><a href="#">our policies</a></li>
 					<li><a href="#">about us</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>offices</h5>
 				<ul>
 					<li><a id="kisumu" href="">kisumu</a></li>
 					<li><a href="#">Nairobi</a></li>
 					<li><a href="#">Mombasa</a></li>
 					<li><a href="#">Nakuru</a></li>
 					<li><a href="#">other Towns</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>get help</h5>
 				<ul>
 					<li><a href="#">FAQ</a></li>
 					<li><a href="#">Shipping</a></li>
 					<li><a href="#">Returns</a></li>
 					<li><a href="#">Orders</a></li>
 					<li><a href="#">payment methods</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>follow us</h5>
 				<div class="social-links">
 					<a href="#"><i class="fab fa-facebook-f"></i></a>
 					<a href="#"><i class="fab fa-twitter"></i></a>
 					<a href="#"><i class="fab fa-linkedin-in"></i></a>
 					<a href="#"><i class="fab fa-instagram"></i></a>
 				</div>
 		</div>
 		</div>
 	</div>

 	</footer>
 	<script src='index.js'>
	</script>
</body>
</html>