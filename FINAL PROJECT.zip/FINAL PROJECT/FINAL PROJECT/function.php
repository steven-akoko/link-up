<<?php 
 function check_login($con)
 {
 $_SESSION['user_id']
 if(isset($_SESSION['user_id']))
 {
 	$id=$_SESSION['user_id'];

 		$query ="select * from user where id ="$id" limit 1";
 		$result =mysqli_query($conn,$query);
 		if($result && mysqli_num_rows($result)>0)
 		{
 			$user_data = mysqli_fetch_assoc($result);
 			return $user_data;
 		}
 }
 //redirect to login
 header("location:login.php");
 die;
}
function random_num($lenght)
{
	$text="";
	if($lenght<5)
	{
		$lenght=5;
	}
	$len= random(4,$length);

	for ($i=0; $i <$len; $i++) { 
		$tetx.=rand(0,9);
	}
	return $text;
}