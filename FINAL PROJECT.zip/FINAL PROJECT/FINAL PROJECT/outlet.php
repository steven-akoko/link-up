<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="outlet.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="./font-awesome/css/font-awesome.min.css">


	<!-- CSS only -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<title>outlet</title>
</head>
<body>
	<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a  href="index.php">Home</a></li>
				<li><a href="services.php">Service</li></a>
				<li><a href="outlet.php" class="active">Find Outlet</a></li>
				<li><a href="trending.php">Business Trending</a></li>
				<li><a href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
		<div class="mainContainer">
			<div class="search-menu">
	<div class="group-input">
	<label>Outlet category:</label>
	<input type="text" id=""placeholder="enter type of service">
</div>
	<div class="group-input">
	<label>location:</label>
	<input type="text"placeholder="enter location">
</div>
<button type="submit" value="submit">Search</button>

	</div>
  <div class="outlets-wrapper">
  	<div class="single-outlet">
  		<div class="main-image">
  			<img id='expandedImg' src="img/siala1.jfif">
  			<div class="image-group">
  				<img  src="img/siala1.jfif" onclick="displayBiggerImage(this);">
  				<img src="img/siala2.jfif" onclick="displayBiggerImage(this);">
  				<img src="img/siala3.jfif" onclick="displayBiggerImage(this);">
  			</div>
  		</div>
  		<div class="descrition-wrapper">
  		<div class="category">
  			<h1>Restaurants and Hotels</h1>
  		</div>
  		<div class="outlet-name">
  			<h1>Ciala Resort</h1>
  		</div>
  		<div class="selection">
  			<select>
  				<option>Contacts</option>
  				<option><a href="">acacia@gmail.com</a></option>
  				<option><a href="">phone number</a></option>
  			</select>
  			<select>
  				<option>view services</option>
  				<option>accomodation</option>
  				<option>swimming</option>
  				<option>gymnastic</option>
  				<option>weddings</option>
  			</select>
  		</div>
  		<div class="outlet-info">
  			<p>Located in Kisumu, 20.9 km from Kisumu Museum, Ciala Resort Hotels In Kisumu has accommodations with a restaurant, free private parking, free bikes and a bar...</p>
  		
  				<a href=""class="view">View</a>
 
  		</div>
  		<div class="rating">
  			<i class="fa fa-star"></i>
  			<i class="fa fa-star"></i> 
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
  		</div>
  	</div>
  	</div>
  	
  	  	<div class="single-outlet">
  		<div class="main-image">
  			<img id='expandedImg' src="img/acacia1.jfif">
  			<div class="image-group">
  				<img  src="img/acacia2.jfif" onclick="displayBiggerImage(this);">
  				<img src="img/acacia3.jfif" onclick="displayBiggerImage(this);">
  				<img src="img/acacia1.jfif" onclick="displayBiggerImage(this);">
  			</div>
  		</div>
  		<div class="descrition-wrapper">
  		<div class="category">
  			<h1>Restaurants and Hotels</h1>
  		</div>
  		<div class="outlet-name">
  			<h1>Acacia premia hotel</h1>
  		</div>
  		<div class="selection">
  			<select>
  				<option>Contacts</option>
  				<option><a href="">acacia@gmail.com</a></option>
  				<option><a href="">phone number</a></option>
  			</select>
  			<select>
  				<option>view services</option>
  				<option>accomodation</option>
  				<option>swimming</option>
  				<option>gymnastic</option>
  				<option>weddings</option>
  			</select>
  		</div>
  		<div class="outlet-info">
  			<p>Located in Kisumu, 20.9 km from Kisumu Museum, Ciala Resort Hotels In Kisumu has accommodations with a restaurant, free private parking, free bikes and a bar...</p>
  		
  				<a href=""class="view">View</a>
 
  		</div>
  		<div class="rating">
  			<i class="fa fa-star"></i>
  			<i class="fa fa-star"></i> 
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
  		</div>
  	</div>
  	</div>
  	

  </div>
    			</div>
    			<!--footer begins here-->
 <footer class="footer">
 	<div class="container-f">
 		<div class="footer-box">
 			<div class="footer-col">
 				<h5>companies</h5>
 				<ul>
 					<li><a href="aboutus.php">about us</a></li>
 					<li><a href="#">affiliate programm</a></li>
 					<li><a href="#">our policies</a></li>
 					<li><a href="#">about us</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>offices</h5>
 				<ul>
 					<li><a id="kisumu" href="">kisumu</a></li>
 					<li><a href="#">Nairobi</a></li>
 					<li><a href="#">Mombasa</a></li>
 					<li><a href="#">Nakuru</a></li>
 					<li><a href="#">other Towns</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>get help</h5>
 				<ul>
 					<li><a href="#">FAQ</a></li>
 					<li><a href="#">Shipping</a></li>
 					<li><a href="#">Returns</a></li>
 					<li><a href="#">Orders</a></li>
 					<li><a href="#">payment methods</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>follow us</h5>
 				<div class="social-links">
 					<a href="#"><i class="fab fa-facebook-f"></i></a>
 					<a href="#"><i class="fab fa-twitter"></i></a>
 					<a href="#"><i class="fab fa-linkedin-in"></i></a>
 					<a href="#"><i class="fab fa-instagram"></i></a>
 				</div>
 		</div>
 		</div>
 	</div>

 	</footer>
 	<script src='index.js'>
	</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
<script>


function displayBiggerImage(imgs) {
var parentdiv=imgs.parentElement
var grandParent=parentdiv.parentElement

  var expandImg = grandParent.querySelector("#expandedImg");

  expandImg.src = imgs.src;
  expandImg.parentElement.style.display = "block";
}



</script>
</body>
</html>