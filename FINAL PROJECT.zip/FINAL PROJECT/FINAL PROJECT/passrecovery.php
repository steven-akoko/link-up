<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="passrecovery.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>passrecovery</title>
</head>
<body>
<a id="Back-btn" href="login.php">Back</a>
<div id="recovery-box" onmousemove="myMoveFunction();">
<div id="form">
	<h1>Recover Password</h1>
	<div class="field"><span class="fa fa-envelope"></span><input type="text"name="username"placeholder="e.g steve@gmail.com"></div>
	<lable>enter your email</lable>
	<div class="field"><input type="text" name="password"placeholder="verification code"></div>
	<button type="submit">verify and Log in</button>
</div>
</div>
<script>
 function myMoveFunction()
 {
	alert"Kindly provide valid email to recover the password";
 }
 myMoveFunction();
</script>
	
</body>
</html>