
/*   $(document).ready(function()
  {
  	$("#login-box").click(function()
  	{
     $("#form").fadeToggle("slow")
  	});
  
  });
 */
const burgerMenu=document.querySelector('.burgerMenu')
const menuItems=document.querySelector('.menuItems')

burgerMenu.addEventListener('click',()=>{
  menuItems.classList.toggle('showMenu')
  console.log('hello')
})

//oulets gallery

