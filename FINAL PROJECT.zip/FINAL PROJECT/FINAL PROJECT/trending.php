<?php
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="trending.css">
	<script defer src="index.js"></script>
	<title>trending</title>
</head>
<body>
	<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a href="index.php">Home</a></li>
				<li><a href="services.php">Service</li></a>
				<li><a href="outlet.php">Find Outlet</a></li>
				<li><a href="trending.php" class="active">Business Trending</a></li>
				<li><a href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
		<!--
		<div class="start-up">
		<h1 class="trending">ALL Trending News</h1>
	-->
		<select class="sorting">
			<option>Sort By</option>
			<option>Date</option>
			<option>Location</option>
			<option>Type</option>
		</select>
	</div> 
	<div class="blog-section">
		<div class="section-content blog">
		<div class="title">
			<h2>daily trendings</h2>
		</div>
		<div class="start-cards">
			<div class="m-card">
				<div class="image-section">
					<img src="img/ukraine1.jfif">
				</div>
				<div class="article">
					<h4>war</h4>
					<p>Turkey more determined 'than ever' to secure Syrian border...</p>
				</div>
				<div class="blog-view">
					<a href="" class="view">Read more</a>
				</div>
				<div class="posted-date">
					<p>posted on Nov 23/2022</p>
				</div>
			</div>
			<div class="m-card">
				<div class="image-section">
					<img src="img/equity.webp">
				</div>
				<div class="article">
					<h4>finance</h4>
					<p>Equity says it is considering setting aside up to Ksh.250 billion for on-lending to boost the government’s financial...</p>
				</div>
				<div class="blog-view">
					<a href=""class="view">Read more</a>
				</div>
				<div class="posted-date">
					<p>posted on Nov 23/2022</p>
				</div>
			</div>
			<div class="m-card">
				<div class="image-section">
					<img src="img/miguna1.webp">
				</div>
				<div class="article">
					<h4>politics</h4>
					<p>'I'll Be Back Soon,' Miguna Says As He Flies Out To London...</p>
				</div>
				<div class="blog-view">
					<a href=""class="view">Read more</a>
				</div>
				<div class="posted-date">
					<p>posted on Nov 23/2022</p>
				</div>
			</div>
		</div>
	</div>
	</div>
	<div class="blog-section">
		<div class="section-content blog">
		<div class="start-cards">
			<div class="m-card">
				<div class="image-section">
					<img src="img/vegancheese.webp">
				</div>
				<div class="article">
					<h4>food</h4>
					<p>Vegan 'cheese' market booms as demand grows...</p>
				</div>
				<div class="blog-view">
					<a href="" class="view">Read more</a>
				</div>
				<div class="posted-date">
					<p>posted on Nov 23/2022</p>
				</div>
			</div>
			<div class="m-card">
				<div class="image-section">
					<img src="img/uk.webp">
				</div>
				<div class="article">
					<h4>international</h4>
					<p>The UK economy will suffer a bigger blow from the global energy crisis than other leading nations, according to...</p>
				</div>
				<div class="blog-view">
					<a href=""class="view">Read more</a>
				</div>
				<div class="posted-date">
					<p>posted on Nov 23/2022</p>
				</div>
			</div>
			<div class="m-card">
				<div class="image-section">
					<img src="img/nigeria.webp">
				</div>
				<div class="article">
					<h4>fashion</h4>
					<p>Nigeria: Teens upcycle rubbish in modern fashion show...</p>
				</div>
				<div class="blog-view">
					<a href=""class="view">Read more</a>
				</div>
				<div class="posted-date">
					<p>posted on Nov 23/2022</p>
				</div>
			</div>
		</div>
	</div>
	</div>
	<!--footer begins here-->
 <footer class="footer">
 	<div class="container-f">
 		<div class="footer-box">
 			<div class="footer-col">
 				<h5>companies</h5>
 				<ul>
 					<li><a href="aboutus.php">about us</a></li>
 					<li><a href="#">affiliate programm</a></li>
 					<li><a href="#">our policies</a></li>
 					<li><a href="#">about us</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>offices</h5>
 				<ul>
 					<li><a id="kisumu" href="">kisumu</a></li>
 					<li><a href="#">Nairobi</a></li>
 					<li><a href="#">Mombasa</a></li>
 					<li><a href="#">Nakuru</a></li>
 					<li><a href="#">other Towns</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>get help</h5>
 				<ul>
 					<li><a href="#">FAQ</a></li>
 					<li><a href="#">Shipping</a></li>
 					<li><a href="#">Returns</a></li>
 					<li><a href="#">Orders</a></li>
 					<li><a href="#">payment methods</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>follow us</h5>
 				<div class="social-links">
 					<a href="#"><i class="fab fa-facebook-f"></i></a>
 					<a href="#"><i class="fab fa-twitter"></i></a>
 					<a href="#"><i class="fab fa-linkedin-in"></i></a>
 					<a href="#"><i class="fab fa-instagram"></i></a>
 				</div>
 		</div>
 		</div>
 	</div>

 	</footer>
  
</body>
</html>