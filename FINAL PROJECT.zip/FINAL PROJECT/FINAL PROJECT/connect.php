<?php
// Enter your Host, username, password, database below.
// I left password empty because i do not set password on localhost.
//$con=mysqli_connect('localhost','root','','servall');
//die("Database not connected");
$con = mysqli_connect("localhost","root","","servall");
?>