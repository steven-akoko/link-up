<?php 
/*
	session_start();
	include("connect.php");
	include("function.php");
	$user_data=check_login($con);
	*/
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="services.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>service</title>
</head>
<body>
	<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a href="index.php">Home</a></li>
				<li><a href="services.php" class="active" >Service</li></a>
				<li><a href="outlet.php">Find Outlet</a></li>
				<li><a href="trending.php">Business Trending</a></li>
				<li><a href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
<!--
	<div class="search-bar">
  		<form>
  				<input type="text"name="text"placeholder="type url/text">
  				<input type="submit"value="search"></button>
  			</div>
  		</form>
  </div>
-->
<div class="search-menu">
	<div class="group-input">
	<label>service category:</label>

	<input type="text" id=""placeholder="enter type of service">
</div>
	<div class="group-input">
	<label>location:</label>
	<input type="text"placeholder="enter location">
</div>
<div class="group-input">
	<label >Add a date:</label>
	<input type="date" placeholder="enter the date">
</div>
<div class="group-input">
	<label>pick a time:</label>
	<input type="time">
</div>
<button type="submit" value="submit">Search</button>
	</div>
	<!-- personell part begins here-->
	<div class="mainCont">
		<div class="individual-person">
	<div class="personeell-item">
		<div class="image-item">
			<img src="img/civil engineer.webp">
		</div>
		<div class="personeell">
			<h1 class="p-category">construction</h1>
			<h1 class="name-role">Melisha -plumber</h1>
			<div class="p-info">
				<p> Steve is a certified plumber who specializes in maintaining systems used for portable water,sewage and drainge system,he earned ...</p>
			</div>
				<a class="more" href="">Learn more</a>
				<div class="p-rating">
					<i class="fa fa-star"></i>
  			<i class="fa fa-star"></i> 
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
				</div>
				<a href="" class="contact">Hire</a>
		</div>
	</div>
	<div class="personeell-item">
		<div class="image-item">
			<img src="img/civil engineer.webp">
		</div>
		<div class="personeell">
			<h1 class="p-category">construction</h1>
			<h1 class="name-role">Melisha -plumber</h1>
			<div class="p-info">
				<p> Steve is a certified plumber who specializes in maintaining systems used for portable water,sewage and drainge system,he earned</p>
			</div>
				<a class="more" href="">Learn more</a>
				<div class="p-rating">
					<i class="fa fa-star"></i>
  			<i class="fa fa-star"></i> 
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
  			<i class="fa fa-star" ></i>
				</div>
				<a href="" class="contact">Hire</a>
		</div>
	</div>
</div>
</div>
	<!--footer begins here.-->
	<footer class="footer">
 	<div class="container-f">
 		<div class="footer-box">
 			<div class="footer-col">
 				<h5>companies</h5>
 				<ul>
 					<li><a href="#">about us</a></li>
 					<li><a href="#">affiliate programm</a></li>
 					<li><a href="#">our policies</a></li>
 					<li><a href="#">about us</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>offices</h5>
 				<ul>
 					<li><a id="kisumu" href="">kisumu</a></li>
 					<li><a href="#">Nairobi</a></li>
 					<li><a href="#">Mombasa</a></li>
 					<li><a href="#">Nakuru</a></li>
 					<li><a href="#">other Towns</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>get help</h5>
 				<ul>
 					<li><a href="#">FAQ</a></li>
 					<li><a href="#">Shipping</a></li>
 					<li><a href="#">Returns</a></li>
 					<li><a href="#">Orders</a></li>
 					<li><a href="#">payment methods</a></li>

 				</ul>
 		</div>
 		<div class="footer-col">
 				<h5>follow us</h5>
 				<div class="social-links">
 					<a href="#"><i class="fab fa-facebook-f"></i></a>
 					<a href="#"><i class="fab fa-twitter"></i></a>
 					<a href="#"><i class="fab fa-linkedin-in"></i></a>
 					<a href="#"><i class="fab fa-instagram"></i></a>
 				</div>
 		</div>
 		</div>
 	</div>

 	</footer>

  
  	<script>
  		const burgerMenu=document.querySelector('.burgerMenu')
const menuItems=document.querySelector('.menuItems')

burgerMenu.addEventListener('click',()=>{
  menuItems.classList.toggle('showMenu')
  console.log('hello')
})
  	</script>

</body>
</html>