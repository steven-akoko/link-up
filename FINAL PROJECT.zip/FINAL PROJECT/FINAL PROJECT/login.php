<!DOCTYPE html>
<?php
session_start();
include 'connect.php';
if (isset($_POST['submit']))
{
   $email=$_POST['email'];
   $password=md5($_POST['password']);
$query=mysqli_query($con,"SELECT * FROM clients WHERE email='$email' and password='$password'");
$num=mysqli_fetch_array($query);
if($num>0)
{
$_SESSION['login']=$_POST['email'];
$_SESSION['id']=$num['id'];
$_SESSION['username']=$num['name'];
$uip=$_SERVER['REMOTE_ADDR'];
$status=1;
$log=mysqli_query($con,"insert into userlog(userEmail,userip,status) values('".$_SESSION['login']."','$uip','$status')");
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
$extra="login.php";
$email=$_POST['email'];
$uip=$_SERVER['REMOTE_ADDR'];
$status=0;
$log=mysqli_query($con,"insert into userlog(userEmail,userip,status) values('$email','$uip','$status')");
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
$_SESSION['errmsg']="Invalid email id or Password";
exit();
}
}


?>

}
?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../lib/w3.css">
	<link rel="stylesheet" type="text/css" href="login.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	 <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	<title>login-form</title>
	<style>
		.error{
			color: red;
		}
	</style>
</head>
<body>
  <body>
		<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class="menuItems">
				<li><a href="index.php">Home</a></li>
				<li><a href="services.php"  >Service</li></a>
				<li><a href="outlet.php">Find Outlet</a></li>
				<li><a href="trending.php">Business Trending</a></li>
				<li><a  class="active" href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
<div class="form-cover">
	<div class="l-instruction">
    <h1 >Welcome to Servall login page</h1>
    <p class="lead">By clicking login in,please put in your credentials i,e username and password to login in .</p>
    <p>and enjoy our services ,throug the page you can change password and create new accounr if you do not have one</p>
</div>
  <form id="form" method="POST" action="" autocomplete="off">
   <i class="fa fa-user"></i>
  	<h1>Login Here</h1>
  		<div class="field"><span class="fa fa-user"></span><input type="text" placeholder="username" name="username"></div>
  		<span class="error"><? php echo $usernameErr;?></span>
  			<div class="field"><span class=" fa fa-lock"></span><input type="password" name="password"placeholder="password">
  				<span class="error"><? php echo $passwordErr;?></span>
  		</div>
  		<div class="pass-ops">
  			<input type="checkbox"><span>remember me</span>
  		 <div class="forgot-password"><a href="passrecovery.php">Forgot password?</a></div>
  		</div>
            <button type="submit" class="submit" name="submit" value="Submit">submit</button>
            <span class="login-form-copy">Or Login with</span>
            <div class="social-icons">
                <div class="social-icon instagram"><span class="fa fa-instagram"></span></div>
                <div class="social-icon facebook"><span class="fa fa-facebook"></span></div>
                <div class="social-icon google"><span class="fa fa-google"></span></div>
                <div class="social-icon linkedin"><span class="fa fa-linkedin"></span></div>
                <div class="social-icon twitter"><span class="fa fa-twitter"></span></div>
            </div>
            <hr style="color:red;width: 100%;">
            <div class="form-copies">
            <p class="form-copy">Don't have an account?</p><span><a href="Register.php" class="sign-up">Sign up</a></span></div>
        </form>
  			</div>
			<div class="login-footer">
				<div class="login-footer-box">
				<div class="login-footer-column">
			<h1>Learn About our:</h1>
			<ul>
			<li><a href="">policies </a></li>
			<li><a href="">privacy</a></li>
			<li><a href="">Terms and Conditions</a></li>
		</ul>
		</div>
		<div class="login-footer-column">
			<h1>Let us be friends</h1>
			<div class="social-links">
 					<a href="#"><i class="fab fa-facebook-f"></i></a>
 					<a href="#"><i class="fab fa-twitter"></i></a>
 					<a href="#"><i class="fab fa-linkedin-in"></i></a>
 					<a href="#"><i class="fab fa-instagram"></i></a>
 				</div>
		</div>
		</div>
			</div>
			<hr style="width:100%;">
			<h1 id="copyright">@servall 2022 copyright</h1>

  			

  		<!--  script begins here-->
  
  			<script>
  				$(document).ready(function()
  				{
  					$("#clickme").click(function()
  					{
  						$("#form").fadeToggle("slow")
  					});
  				});
		  const burgerMenu=document.querySelector('.burgerMenu')
     const menuItems=document.querySelector('.menuItems')

		burgerMenu.addEventListener('click',()=>{
		  menuItems.classList.toggle('showMenu')
		  console.log('hello')
		})
  			</script>
  			<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
<script>
</body>
</html>