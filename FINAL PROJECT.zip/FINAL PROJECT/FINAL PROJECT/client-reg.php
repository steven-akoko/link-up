<!DOCTYPE html>
<?php 
 include 'connect.php';
 if(isset($_POST['signup_btn']))
 {
 	$firstname=mysqli_real_escape_string($con,$_POST['firstname']);
   $lastname=mysqli_real_escape_string($con,$_POST['lastname']);
   $email=mysqli_real_escape_string($con,$_POST['email']);
   $password=mysqli_real_escape_string($con,$_POST['password']);
   $password2=mysqli_real_escape_string($con,$_POST['password2']);
   //validating the user inputs
   if (empty($_POST['firstname'])) {

   	 $error="name must be filled";
   }
   else if (empty($lastname)) {
   	$error="lastname must be filled";
   }
   else if (empty($email)) {
   	$error="email must be filled";
   }
   else if (empty($password)) {
   	$error="password must be filled";
   }
   else if ($password!=$password2) {
   	$error="password do no match";
   }
   else if (strlen($firstname)< 3 || strlen($firstname)>30){
   	$error="the length of name must not be les than 3 and exceeding 30";
   }
   else
   {
   	$check_email="SELECT * FROM clients WHERE  email='$email'";
   	$data=mysqli_query($con,$check_email);
   	$result=mysqli_fetch_array($data);
   	if ($result>0) {
   		$error="the email already exists";
   	}
   	else
   	{   $pass=md5($password);
   		$insert="INSERT INTO clients(firstname,lastname,email,password) values('$firstname','$lastname','$email','$pass')";
   		$q=mysqli_query($con,$insert);
   		if($q)
   		{
   			$success="You have registered successfully";
   			header("location: login.php");
   		}
   	}
   }

 

 }
 ?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>client-registration page</title>
	<link rel="stylesheet" type="text/css" href="client-reg.css">
	<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<nav>
			<label class="logo">Serv<span>ALL</span></label>
			<ul class='menuItems'>
				<li><a href="index.php">Home</a></li>
				<li><a href="services.php"  >Service</li></a>
				<li><a href="outlet.php">Find Outlet</a></li>
				<li><a href="trending.php">Business Trending</a></li>
				<li><a  class="active" href="login.php">Login/sign-up</a><li>
			</ul>
			<div class='burgerMenu'>
			<span></span>
			<span></span>
			<span></span>
			<div>
		</nav>
	<a href="client-reg.php"></a>
	<h1 style="text-align:center;margin:10px;">Create your account down below</h1>
	<div class="main-reg-form">
		
	<form id="form" action="client-reg.php" method="POST">
	<i class="fa fa-user"></i>
	<h1>Register</h1>
	<p>
			<?php 
			if (isset($error)) {
				echo $error;
			}
			 ?>
		</p>
		<p style="color:green;">
			<?php 
			if (isset($success)) {
				echo $success;
			}
			 ?>
		</p>
	<div class="field"><span class="fa fa-user"></span><input type="text" name="firstname"placeholder="enter first name"value="<?php if(isset($error))
	echo $firstname;
   ?>">
	 </div>
		<div class="field"><span class="fa fa-user"></span><input type="text"name="lastname"placeholder="enter last name" value="<?php if (isset($error)) {
			echo $lastname;
		} ?>">
		</div>
		<div class="field"><span class="fa fa-envelope"></span><input type="email" name="email"placeholder="enter email" value="<?php if (isset($error)) {echo $email; 
		}
		?>
			">
		</div>
			<div class="field"><span class="fa fa-lock"></span><input type="password1"name="password"placeholder="enter password" value="<?php if (isset($error)) {
				echo $password;
			} ?>">
			</div>
			<div class="field"><span class="fa fa-lock"></span><input type="password2"name="password2"placeholder="confirm password" value="<?php if(isset($error))
			{ echo $password2;
				} ?>">
			</div>
			<div class="R-terms">
				<input type="checkbox"><span>I agree to the terms and conditions.</span>
			</div>
			<button type="submit" name="signup_btn" value="submit">Register</button>
			<div class="login-opt">
            <p class="opt">Already have an account?</p><span><a href="login.php" class="l-link">Login</a></span></div>
		</form>
	</div>
	

	<script >
		swal({  
  title: " Oops!",  
  text: " Something went wrong, you should choose again!",  
  icon: "error",  
  button: "oh no!",  
});  
		
	</script>
</body>
</html>